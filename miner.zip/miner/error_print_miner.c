/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error_print.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjane-ta <jjane-ta@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/10 14:05:26 by jjane-ta          #+#    #+#             */
/*   Updated: 2022/08/18 12:56:17 by jjane-ta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header_miner.h"

int	error_print(const char *trace, const char *const str)
{
//	static int	error_printed = 0;

//	if (!error_pirinted)
	if (str) /// 
	{
		write(2, RED, strlen(RED));
		write(2, "error: ", 7);
		write(2, YELLOW, strlen(YELLOW));
		/*
		if (!str)
			write(2, "YOU MUST NEED DEFINE ERROR!!!!!!",
				   	strlen("YOU MUST NEED DEFINE ERROR!!!!!!"));
		else
		*/
			write(2, str, strlen(str));
			write(2, ".\n", 2);
			write(2, RESET, strlen(RESET));

	//	error_printed = 1;
	}
	if (DEBUG)
	{	
		write(2, CYAN, strlen(CYAN));
		write(2, "=> ", 3);
		write(2, trace, strlen(trace));
		write(2, RESET, strlen(RESET));
		write(2, "\n", 1);
	}
	return (1);
}
