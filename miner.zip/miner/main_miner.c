/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_miner.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjane-ta <jjane-ta@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/10 12:21:47 by jjane-ta          #+#    #+#             */
/*   Updated: 2022/08/19 15:05:57 by jjane-ta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header_miner.h"

int	main(void)
{
	t_global g;
	
	if (main_init_global(&g))
	{
		main_reset_vars(&g);
		//main_free_global(&g);
		return (error_print("main", NULL)); 
	}

	main_clear_win(&g);
	mlx_launch_menu(&g);
	mlx_hook(g.mlx_win, 17, 0, mlx_close_window, &g);

	mlx_loop(g.mlx);
	return (0);
}

int	main_init_global(t_global *g)
{
	g->line = 0;
	g->n_line = 0;
	g->url = NULL;
	g->value = NULL;
	g->response = NULL;
	g->mlx = NULL;
	g->mlx_win = NULL; 
	g->img = NULL;
	g->clean = NULL;
	g->mlx = mlx_init();
	if (!g->mlx)
		return (error_print("main_init_global", "MLX init error")); 
	g->mlx_win = mlx_new_window(g->mlx, X_WIN, Y_WIN, "MINER");
	if (!g->mlx_win)
		return (error_print("main_init_global", "MLX window error")); 
	g->img = mlx_xpm_file_to_image(g->mlx, "button_retro.xpm", &g->b_size.x, &g->b_size.y);
	if (!g->img)
		return (error_print("main_init_global", "MLX open button_retro.xpm fail")); 
	g->clean = mlx_new_image(g->mlx, 1000, 1000);
	if (!g->clean)
		return (error_print("main_init_global", "MLX new image fail")); 
	
	
	mlx_init_square(g);

	return (0);
}

int	main_reset_vars(t_global *g)
{
	if (g->url)
	{
		free(g->url);
		g->url = NULL;
	}
	if (g->value)
	{
		free(g->value);
		g->value = NULL;
	}
	if (g->response)
	{
		free(g->response);
		g->response = NULL;
	}
	return (0);
}

int	main_clear_win(t_global *g)
{
	mlx_put_image_to_window(g->mlx, g->mlx_win, g->clean, 0, 0);
	g->str_pos.x = 0;
	g->str_pos.y = 0;
	if (DEBUG)
		main_print_debug_alert(g);
	else
		main_print_miner_header(g);
	g->str_pos.x = 50;
	g->str_pos.y = 100;
	return(0);
}

int	main_print_debug_alert(t_global *g)
{
	g->str_pos.x += 200;
	mlx_str(g, "////////////////////////////////////////////////////////////\n");
	mlx_str(g, "////////////            DEBUG MODE           ///////////////\n");
	mlx_str(g, "////////////////////////////////////////////////////////////\n");
	g->str_pos.x -= 200;
	return (0);
}

int	main_print_miner_header(t_global *g)
{
	g->str_pos.x += 200;
	mlx_str(g, "///////////////////////////////////////////////////////////\n");
	mlx_str(g, "////////////         BlockChain Miner        //////////////\n");
	mlx_str(g, "///////////////////////////////////////////////////////////\n \n");
	g->str_pos.x -= 200;
	return (0);
}
