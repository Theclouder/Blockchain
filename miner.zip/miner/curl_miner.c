/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   miner.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjane-ta <jjane-ta@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/08 17:39:34 by jjane-ta          #+#    #+#             */
/*   Updated: 2022/08/19 15:24:40 by jjane-ta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header_miner.h"

static int	curl_error_print(t_global *g, char *path, const char *error);

int	curl_set_url(t_global *g)
{
	static const char	*protocol = "http:";
	int	size;

	size = strlen(protocol)
		   		+ 2
			   	+ strlen(g->args.ip)
			   	+ 1
			   	+ strlen(g->args.port)
			   	+ 1
			   	+ strlen(ADDRESS[g->args.opt])
			   	+ 1;
	g->url = malloc(size + 1);
	if (!g->url)
		return (error_print("curl_set_url", "Malloc fail"));
	snprintf (g->url, size + 1, "%s//%s:%s/%s",
		   	protocol, g->args.ip, g->args.port, ADDRESS[g->args.opt]);
	return (0);
}

int	curl_opt(t_global *g)
{
	switch(g->args.opt)
	{
		case NEW:
			g->args.data = "recipient=jj&amount=42"; /////
			if (curl_post(g))
				return (error_print("curl_opt", NULL));
			if (g->response)
			{
				mlx_str(g, g->response);
				free(g->response);
				g->response = NULL;
			}
			break ;
		case MINE:
			if (curl_get(g))
				return (error_print("curl_opt", NULL));
			if (proof_main(g))
				return (error_print("curl_opt", NULL));
			g->args.data = g->value;
			free(g->response);
			g->response = NULL;	
			if (curl_post(g))
				return (error_print("curl_opt", NULL));
			if (g->response)
			{
				mlx_str(g, g->response);
				free(g->response);
				g->response = NULL;
			}
			break ;
		case STATUS:
   			if (curl_get(g))
				return (error_print("curl_opt", NULL));
			t_pos pos;
			pos.x = g->str_pos.x;
   			pos.y = g->str_pos.y;
			g->str_pos.x = 265;
   			g->str_pos.y = 910;
			mlx_put_button(g, &g->b5, "                   Menu");
			g->str_pos.x = pos.x;
   			g->str_pos.y = pos.y;
			mlx_print_response(g);
			break ;
		case QUIT:
			return (0);
		default :
			return (1);
	}
	return (0);
}

int	curl_post(t_global *g)
{
	CURLcode	res;

	curl_init(g);
	if (curl_easy_setopt(g->curl, CURLOPT_URL, g->url) != CURLE_OK)
		return (curl_error_print(g, "curl_post", "Curl setopt url fail"));
	if (curl_easy_setopt(g->curl, CURLOPT_POSTFIELDS, g->args.data) != CURLE_OK)
		return (curl_error_print(g, "curl_post", "Curl setopt data fail"));
	if (curl_easy_setopt(g->curl, CURLOPT_FOLLOWLOCATION, 1L) != CURLE_OK)
		return (curl_error_print(g, "curl_post", "Curl setopt location fail"));
	if (curl_easy_setopt(g->curl, CURLOPT_TIMEOUT, 10) != CURLE_OK)
		return (curl_error_print(g, "curl_post", "Curl setopt timeout fail"));
	if (curl_easy_setopt(g->curl, CURLOPT_WRITEFUNCTION, curl_write_func) != CURLE_OK)
		return (curl_error_print(g, "curl_post", "Curl setopt write function fail"));
	if (curl_easy_setopt(g->curl, CURLOPT_WRITEDATA, &g->response) != CURLE_OK)
		return (curl_error_print(g, "curl_post", "Curl setopt write data fail"));
	res = curl_easy_perform(g->curl);
	if (res != CURLE_OK)
		return (curl_error_print(g, "curl_post", curl_easy_strerror(res)));
	curl_clean(g);
	return (0);
}

int	curl_get(t_global *g)
{
	CURLcode	res;

	curl_init(g);
	if (curl_easy_setopt(g->curl, CURLOPT_URL, g->url) != CURLE_OK)
		return (curl_error_print(g, "curl_get", "Curl setopt url fail"));
	if (curl_easy_setopt(g->curl, CURLOPT_FOLLOWLOCATION, 1L) != CURLE_OK)
		return (curl_error_print(g, "curl_get", "Curl setopt location fail"));
	if (curl_easy_setopt(g->curl, CURLOPT_TIMEOUT, 10) != CURLE_OK)
		return (curl_error_print(g, "curl_get", "Curl setopt timeout fail"));
	if (curl_easy_setopt(g->curl, CURLOPT_WRITEFUNCTION, curl_write_func) != CURLE_OK)
		return (curl_error_print(g, "curl_get", "Curl setopt write function fail"));
	if (curl_easy_setopt(g->curl, CURLOPT_WRITEDATA, &g->response) != CURLE_OK)
		return (curl_error_print(g, "curl_get", "Curl setopt write data fail"));
	res = curl_easy_perform(g->curl);
	if (res != CURLE_OK)
		return (curl_error_print(g, "curl_get", curl_easy_strerror(res)));
	curl_clean(g);
	return (0);
} 

static int	curl_error_print(t_global *g, char *path, const char *error)
{
	curl_clean(g);
	return (error_print(path, error));
}

size_t	curl_write_func(void *ptr, size_t size, size_t nmemb, char **response)
{
	int		offset;
	char	*str;

	offset = 0;
	if (response[0])
		offset = strlen(response[0]);
	str = malloc(offset + (size * nmemb) + 1);
	if (!str)
	{
		if (response[0])
			free(response[0]);
		return (CURLE_WRITE_ERROR);
	}
	if (offset)
		str = strcpy(str , response[0]);
	memcpy(str + offset , ptr, size * nmemb);
 	(str + offset)[size * nmemb] = '\0';
	free(response[0]);
	response[0] = str;
	return (size*nmemb);
}

int	curl_init(t_global *g)
{
	if (curl_global_init(CURL_GLOBAL_SSL) != CURLE_OK)
		return (error_print("curl_init", "CURL global init fail"));
	g->curl = curl_easy_init();
	if (!g->curl)
	{
		curl_global_cleanup();
		return (error_print("curl_init", "CURL easy init fail"));
	}
	return (0);
}

int	curl_clean(t_global *g)
{
	if (g->curl)
		curl_easy_cleanup(g->curl);
	curl_global_cleanup();
	return (0);
}
