/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_sha256.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjane-ta <jjane-ta@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/09 15:25:43 by jjane-ta          #+#    #+#             */
/*   Updated: 2022/08/18 15:10:05 by jjane-ta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header_miner.h"

int	sha256(unsigned char * md_value, char *proof, char *value)
{
	EVP_MD_CTX		*ctx;
	const			EVP_MD *md;
	unsigned int	md_len;

	if (!value || !proof)
		return (1);
	md = EVP_get_digestbyname("sha256");
	if (!md) 
		return (2);
	ctx = EVP_MD_CTX_new();
	if (!ctx) 
		return (3);
	if (EVP_DigestInit_ex(ctx, md, NULL) != 1)
		return (4);
	if (EVP_DigestUpdate(ctx, proof, strlen(proof)) != 1)
		return (5);
	if (EVP_DigestUpdate(ctx, value, strlen(value)) != 1)
		return (6);
	if (EVP_DigestFinal_ex(ctx, md_value, &md_len) != 1)
		return (7);
	EVP_MD_CTX_free(ctx);
	return (0);
}

void	error_sha256(int error)
{
	static char	*str[] = {"[0] Not defined."
						, "[1] Null params."
						, "[2] Fail to create Digest method sha256."
						, "[3] Fail to create Digest context."
						, "[4] Fail to init Digest."
						, "[5] Fail to update proof on Digest." 
						, "[6] Fail to update value on Digest."
						, "[7] Fail on Digest Final."};
	write(2, "error: On sha256 => ", 20);
	write(2, str[error], strlen(str[error]));
	write(2, "\n", 1); 
}

int	proof_of_work(t_global *g)
{
	static unsigned long value_long = 0;
	unsigned char	res[SHA256_SIZE + 1];

	while(1)
	{
		res[SHA256_SIZE] = '\0';
		snprintf(g->value, ULONG_MAX_SIZE + 1, "%lx", value_long);
		if (!g->value | !g->response)
			return (error_print("proof_of_work", "Void vars"));
		if (sha256(res, g->response, g->value))
			return (error_print("proof_of_work", NULL));
		snprintf((char *)res, 5, "%02x%02x", res[30], res[31]);
		if (!strcmp((char *)res, "4242"))
			break ;
		value_long++;
		if (value_long == ULONG_MAX)
			return(1);
	}
	return (0);
}

void	error_proof_of_work(int error)
{
	static const char	*const str[] = {"[0] Not defined."
						, "[1] Out of range."
						, "[2] Malloc fail."
						, NULL};
	if (str[error])
	{
		write(2, "error: On sha256 => ", 20);
		write(2, str[error], strlen(str[error]));
		write(2, "\n", 1); 
	}
}


void	print_bytes(unsigned char *bytes, int size)
{
	int	i;
	
	i = 0;
	while (i < size)
		printf("%02x", bytes[i++]);	
}


int	proof_main(t_global *g)
{
	g->value = malloc(ULONG_MAX_SIZE + 1);
	if (!g->value)
		return (error_print("proof_main", "Malloc fail"));
	if (proof_of_work(g))
		return (error_print("proof_main", NULL));
	return (0);
}

