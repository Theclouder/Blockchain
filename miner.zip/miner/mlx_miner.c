/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mlx_miner.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjane-ta <jjane-ta@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/17 15:37:12 by jjane-ta          #+#    #+#             */
/*   Updated: 2022/08/19 15:57:51 by jjane-ta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header_miner.h"
#include "libft.h"

static int v_size(char **v);
static void	my_mlx_pixel_put(t_data *data, int x, int y, int color);
static int	mlx_win_scroll_handler(int button, int x, int y, void *param);


int	mlx_print_response(t_global *g)
{
	static t_pos pos;

	if (!pos.x)
	{
		pos.x =	g->str_pos.x ;
		pos.y = g->str_pos.y;
	}
	g->str_pos.x = pos.x;
	g->str_pos.y = pos.y;
	mlx_print_square(g);
	g->str_pos.x = pos.x;
	g->str_pos.y = pos.y;
	mlx_mouse_hook(g->mlx_win, mlx_win_scroll_handler, g);
	mlx_str(g, g->response);
	return (0);
}

int	mlx_print_square(t_global *g)
{
	mlx_put_image_to_window(g->mlx, g->mlx_win, g->square.img, g->str_pos.x - 10 , g->str_pos.y);
	g->scroll_0.x = g->str_pos.x; 
	g->scroll_0.y = g->str_pos.y;


	return (0);
}


static void	my_mlx_pixel_put(t_data *data, int x, int y, int color)
{
	char	*dst;

	dst = data->addr + (y * data->line_length + x * (data->bits_per_pixel / 8));
	*(unsigned int*)dst = color;
}

int	mlx_init_square(t_global *g)
{	
	int	i = 0;
	
	g->line = 0;

	g->square.img = mlx_new_image(g->mlx, X_SCROLL + 1, Y_SCROLL + 1);
	g->square.addr = mlx_get_data_addr(g->square.img, 
			&g->square.bits_per_pixel, &g->square.line_length, &g->square.endian);
	while (i++ < X_SCROLL)
		my_mlx_pixel_put(&g->square, i , 0 , 0x00FF0000);
	i = 0;
	while (i++ < Y_SCROLL)
	{
		my_mlx_pixel_put(&g->square,  0, i , 0x00FF0000);
		my_mlx_pixel_put(&g->square,  X_SCROLL  ,  i , 0x00FF0000);
	}
	i = 0;
	while (i++ < X_SCROLL)
		my_mlx_pixel_put(&g->square, i , Y_SCROLL  , 0x00FF0000);
	return (0);
}



int	mlx_str(t_global *g, char *str)
{
	char **v_str = ft_split(str, '\n');
	
	g->n_line = v_size(v_str);


	int i;
	int u;
	
	i = g->line;	
	u = g->n_line;
	if (g->n_line + i > 40)
		u = 40 + i ;
	while(i < u  && v_str[i])
	{
		mlx_string_put(g->mlx, g->mlx_win, g->str_pos.x , g->str_pos.y, 0x00FF0000, v_str[i]);
		g->str_pos.y += 20;
		i++;
	}
	i = 0;
	while (i < g->n_line)
		free(v_str[i++]);	
	free(v_str);
	return (0);
}

static int v_size(char **v)
{
	int	lines = 0;
	if (!v)
		return (0);
	while (v[lines])
		lines++;
	return (lines);
}

static int	mlx_win_scroll_handler(int button, int x, int y, void *param)
{
	t_global *g = (t_global *) param;

	if (x >= g->b5.x && y >= g->b5.y && x <= g->b5.x + g->b_size.x && y <= g->b5.y + g->b_size.y
		   	&& button == 1)
	{
		g->line = 0;
		main_reset_vars(g);
		main_clear_win(g);
		if (mlx_launch_menu(g))
			return (0);
	}
	else if (x >= g->scroll_0.x && y >= g->scroll_0.y
		   	&& x <= g->scroll_0.x + X_SCROLL 
			&& y <= g->scroll_0.y + Y_SCROLL
		   	&& (button == 4 || button == 5))
	{
		if (button == 4 && g->line < g->n_line )
			g->line++;
		else if (button == 5  && g->line > 0 )
			g->line--;
		else
			return (0);
		mlx_print_response(g);
	}
	return (0);
}


static int	mlx_win_mouse_handler(int button, int x, int y, void *param)
{
	t_global *g = (t_global *) param;

	(void)x;
	(void)y;
	if (button != 1)
		return (0);
	main_reset_vars(g);
	main_clear_win(g);
	if (mlx_launch_menu(g))
		return (0);
	return (0);
}

static int	mlx_menu_mouse_handler(int button, int x, int y, void *param)
{
	(void)button;
	t_global *g = (t_global *) param;

	g->line = 0;
	g->n_line = 0;
	if (button != 1)
		return (0);
	g->args.ip = "localhost";
	g->args.port = "5000";
	if (x >= g->b1.x && y >= g->b1.y && x <= g->b1.x + g->b_size.x && y <= g->b1.y +  g->b_size.y )
		g->args.opt = NEW;
	else if (x >=g->b2.x && y >=g->b2.y && x <= g->b2.x + g->b_size.x && y <=g->b2.y +  g->b_size.y )
		g->args.opt = MINE;
	else if(x >= g->b3.x && y >= g->b3.y && x <= g->b3.x + g->b_size.x && y <= g->b3.y + g->b_size.y )
		g->args.opt = STATUS;
	else if(x >= g->b4.x && y >= g->b4.y && x <= g->b4.x + g->b_size.x && y <= g->b4.y + g->b_size.y )
	{
		main_reset_vars(g);
		exit (1);
	}
	else
		return (1);

	if (curl_set_url(g))
		exit(error_print("mlx_menu", NULL));
	mlx_mouse_hook(g->mlx_win, mlx_win_mouse_handler , g);
	main_clear_win(g);
	if (curl_opt(g))
	{
		mlx_str(g, "    Ups!! Something wrong with curl");
		return (error_print("mlx_menu" , NULL));
	}
	return (0);
}

int	mlx_put_button(t_global *g, t_pos *pos, char *name)
{
	pos->x = g->str_pos.x;
   	pos->y = g->str_pos.y;
	mlx_put_image_to_window(g->mlx, g->mlx_win, g->img, pos->x, pos->y);
	g->str_pos.x += 10;
   	g->str_pos.y += 10 ;
 	mlx_str(g, name);
	g->str_pos.x -= 10;
   	g->str_pos.y += 10 + g->b_size.y -10;
	return (0);
}

int	mlx_launch_menu(t_global *g)
{
	g->str_pos.x += 200;
	mlx_str(g, "Welcome to the best miner app on the World!!");
	g->str_pos.y += 20;

	mlx_str(g, "          Please select one option:");
	mlx_put_button(g, &g->b1, "           Send New transaction");
	mlx_put_button(g, &g->b2, "      Request and Mine a transaction");
	mlx_put_button(g, &g->b3, "    Print the Status of the Blockchain");
	mlx_put_button(g, &g->b4, "                  Quit");
	mlx_mouse_hook(g->mlx_win, mlx_menu_mouse_handler , g);
	g->str_pos.x = -200;
	return (0);
}

int	mlx_close_window(t_global *g)
{
	main_reset_vars(g);
	exit (0);
}
