/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header_miner.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjane-ta <jjane-ta@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/10 12:17:50 by jjane-ta          #+#    #+#             */
/*   Updated: 2022/08/19 15:33:25 by jjane-ta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DEBUG
# define DEBUG 0
#endif

#ifndef HEADER_MINER_H 
# define HEADER_MINER_H 


# include <unistd.h>
# include <string.h>
# include <sys/errno.h>



// for sha256
# include <stdio.h>
# include <limits.h>
# include <openssl/evp.h>

#define SHA256_SIZE 32
#define ULONG_MAX_SIZE 26 
#define X_WIN 975
#define Y_WIN 1000
#define X_SCROLL 900
#define Y_SCROLL 802

// for curl
# include <curl/curl.h>
# include <stdlib.h>
# include "mlx.h"
# include "colors.h"

enum OPS {OTHER, NEW, MINE, STATUS, QUIT};
#define ADDRESS (char*[]) {NULL, "transactions/new?", "mine", "chain"}




typedef struct	s_data {
	void	*img;
	char	*addr;
	int		bits_per_pixel;
	int		line_length;
	int		endian;
}	t_data;


typedef struct s_args
{
	int		opt; 
	char	*ip;
	char	*port;
	char	*path;
	char	*data;
}	t_args;

typedef struct s_pos
{
	int	x;
	int	y;
}	t_pos;

typedef struct s_global
{
	t_data	square;
	t_args	args;
	void	*mlx;
	void	*mlx_win;
	t_pos	str_pos;
	void	*img;
	void	*clean;
	t_pos	b_size;
	t_pos	b1;
	t_pos	b2;
	t_pos	b3;
	t_pos	b4;
	t_pos	b5;
	t_pos	scroll_0;
	char	*url;
	CURL	*curl;
	char	*value;
	char	*response;
	int		line;
	int		n_line;
}	t_global;

////////////////////////////////// main_miner.c ////////////////////////////////

//int	main_set_args(t_global *g, int argc, char *argv[]);
int	main_print_debug_alert(t_global *g);
int	main_init_global(t_global *g);
int	main_reset_vars(t_global *g);
int	main_free_global(t_global *g);
int	main_clear_win();
int	main_print_miner_header(t_global *g);

////////////////////////////////// curl_miner.c ////////////////////////////////

int	curl_init(t_global *g);
int	curl_clean(t_global *g);
int	curl_set_url(t_global *g);
int	curl_opt(t_global *g);
int	curl_post(t_global *g);
int	curl_get(t_global *g);
size_t	curl_write_func(void *ptr, size_t size, size_t nmemb, char **response);

///////////////////////////////// error_print.c ////////////////////////////////

int	error_print(const char *trace, const char *const str);
//void	error_main_set_args(int error);

///////////////////////////////// sha256_miner.c ///////////////////////////////
int	proof_main(t_global *g);
int	sha256(unsigned char * md_value, char *proof, char *value);
void	error_sha256(int error);
int	proof_of_work(t_global *g);
void	error_proof_of_work(int error);
void	print_bytes(unsigned char *bytes, int size);

///////////////////////////////// mlx_miner.c //////////////////////////////////
int	mlx_str(t_global *g, char *str);
int	mlx_launch_menu(t_global *g);
//int	mlx_menu_mouse_handler(int button, int x, int y, void *param);
int	mlx_close_window(t_global *g);
int	mlx_init_square(t_global *g);
int	mlx_print_square(t_global *g);
int	mlx_print_response(t_global *g);
int	mlx_put_button(t_global *g, t_pos *pos, char *name);

#endif
