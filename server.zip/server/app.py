import sys
import random
import hashlib
from flask import Flask
from flask import request
from datetime import datetime
from flask import render_template
from werkzeug.middleware.proxy_fix import ProxyFix

list_pending = []
list_completed = []
sender = "24cc12fb62a06c9b2"

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app)

@app.route('/')
def index():
   return render_template("forehead.html")

@app.route('/transactions/new', methods=['POST'])
def route():
    if request.form:
        keys = list(request.form.keys())
        values = list(request.form.values())
        if keys[0] == "recipient" and keys[1] == "amount":
            fill_pending(values, None, None)
        else:
            return "Error: values not sended correctly!"
        return "Transaction added correctly!"
    else:
        return "Nothing received!"

@app.route('/mine', methods=['GET', 'POST'])
def get_mine():
    if request.method == 'GET':
        if not list_pending:
            return "No mining to be done!"
        return list_pending[0]["proof"]
    else:
        if not list_pending:
            return "No mining to be done!"
        recipient = list(request.form.values())[0]
        result = list_pending[0]["proof"] + list(request.form.keys())[0]
        hashed = hashlib.sha256(result.encode('utf-8')).hexdigest()
        if hashed[-4:] == "4242":
            return fill_completed(hashed)
        else:
            return "Miner did not make a good job!"

@app.route('/internet', methods=['GET'])
def browser_page():
    return "Pending: " + print_dict(list_pending, "<br>", "&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;") + \
            "<br>Completed: " + print_dict(list_completed, "<br>", "&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;")

@app.route('/chain', methods=['GET'])
def pc_page():
    return "Pending: " + print_dict(list_pending, "\n", "\t") + "\nCompleted: " + print_dict(list_completed, "\n", "\t")

def fill_pending(values, recipient, amount):
    if not recipient and not amount:
        dict_tr = {"sender" : sender, "recipient" : values[0], "amount" : values[1]}
    else:
        dict_tr = {"sender" : sender, "recipient" : recipient, "amount" : amount}
    pend = {"index" : "-1"}
    pend["timestamp"] = datetime.now().strftime("%Y%m%d%H%M.%S")
    pend["transaction"] = dict_tr
    pend["proof"] = str(random.getrandbits(48))
    pend["previous hash"] = "-1"
    list_pending.append(pend)

def fill_completed(hashed):
    if not list_completed:
        index = "0"
        prev_hash = "0"
    else:
        index = str(int(list_completed[-1]["index"]) + 1)
        prev_hash = hashed
    amount = "0.12"
    recipient = list_pending[0]["transaction"]["recipient"]
    list_completed.append(list_pending[0])
    list_completed[-1]["index"] = index
    list_completed[-1]["timestamp"] = datetime.now().strftime("%Y%m%d%H%M.%S")
    list_completed[-1]["previous hash"] = prev_hash
    del list_pending[0]
    fill_pending(None, recipient, amount);
    return "Good job miner! You will be paid for your work!"

def print_dict(res, char, tab):
    string = ""
    if not res:
        return " No transactions!\n"
    for items in res:
        string += char + "   {" + char
        for key,value in items.items():
            string += tab + key + ": "
            if type(value) is dict:
                string += "[" + char + tab + "   {" + char
                for name, desc in value.items():
                    string += tab + tab + name + ": " + desc + "," + char
                string += tab + "   }" + char + tab + "]," + char
            else:
                string += value + "," + char
        string += "   }" + char
    return string
